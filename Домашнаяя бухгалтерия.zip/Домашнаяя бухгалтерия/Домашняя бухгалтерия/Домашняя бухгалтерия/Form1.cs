﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Домашняя_бухгалтерия
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            TypeSelect.Items.Add("Доход");
            TypeSelect.Items.Add("Расход");

            string connString = "server=localhost;port=3306;username=root;database=houseaccount";
            string query = "SELECT * FROM account";

            using (MySqlConnection conn = new MySqlConnection(connString))
            {
                conn.Open();
                using (MySqlDataAdapter adapter = new MySqlDataAdapter(query, conn))
                {
                    DataSet ds = new DataSet();
                    adapter.Fill(ds);
                    AccountTable.DataSource = ds.Tables[0];
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MySqlConnection connection = new MySqlConnection("server=localhost;port=3306;username=root;database=houseaccount");
            connection.Open();
            MySqlCommand command = new MySqlCommand("INSERT INTO account(Дата, Приход_расход, Категория, Сумма, Комментарий) VALUES(@date, @type, @category, @amount, @comment)", connection);
            command.Parameters.Add("@date", MySqlDbType.VarChar).Value = DatePicker.Text;
            command.Parameters.Add("@type", MySqlDbType.VarChar).Value = TypeSelect.SelectedItem;
            command.Parameters.Add("@category", MySqlDbType.VarChar).Value = CategorySelect.SelectedItem;
            command.Parameters.Add("@amount", MySqlDbType.Int32).Value = AmountText.Text;
            command.Parameters.Add("@comment", MySqlDbType.VarChar).Value = CommentText.Text;
            if((TypeSelect.SelectedItem == null) || (CategorySelect.SelectedItem == null) || (AmountText.Text == "") || (CommentText.Text == "")) {
                MessageBox.Show("Заполните все поля");
            } else
            {
                command.ExecuteNonQuery();
            }
            string connString = "server=localhost;port=3306;username=root;database=houseaccount";
            string query = "SELECT * FROM account";

            using (MySqlConnection conn = new MySqlConnection(connString))
            {
                using (MySqlDataAdapter adapter = new MySqlDataAdapter(query, conn))
                {
                    DataSet ds = new DataSet();
                    adapter.Fill(ds);
                    AccountTable.DataSource = ds.Tables[0];
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MySqlConnection connection = new MySqlConnection("server=localhost;port=3306;username=root;database=houseaccount");
            connection.Open();
            MySqlCommand command = new MySqlCommand("DELETE FROM account WHERE ID = @ID", connection);
            command.Parameters.Add("@ID", MySqlDbType.Int32).Value = IDText.Text;
            if(IDText.Text == "")
            {
                MessageBox.Show("Заполните поле ID");
            } else
            {
                command.ExecuteNonQuery();
            }

            string connString = "server=localhost;port=3306;username=root;database=houseaccount";
            string query = "SELECT * FROM account";

            using (MySqlConnection conn = new MySqlConnection(connString))
            {
                using (MySqlDataAdapter adapter = new MySqlDataAdapter(query, conn))
                {
                    DataSet ds = new DataSet();
                    adapter.Fill(ds);
                    AccountTable.DataSource = ds.Tables[0];
                }
            }
        }

        private void TypeSelect_SelectedIndexChanged(object sender, EventArgs e)
        {
            string SelectedType = TypeSelect.SelectedItem.ToString();
            switch(SelectedType)
            {
                case "Доход":
                    CategorySelect.Items.Remove("Продукты питания");
                    CategorySelect.Items.Remove("Транспорт");
                    CategorySelect.Items.Remove("Мобильная связь");
                    CategorySelect.Items.Remove("Интернет");
                    CategorySelect.Items.Remove("Развлечения");
                    CategorySelect.Items.Remove("Другое");
                    CategorySelect.Items.Add("Заработная плата");
                    CategorySelect.Items.Add("Сдача в аренду");
                    CategorySelect.Items.Add("Другое");
                    break;
                case "Расход":
                    CategorySelect.Items.Remove("Заработная плата");
                    CategorySelect.Items.Remove("Сдача в аренду");
                    CategorySelect.Items.Remove("Другое");
                    CategorySelect.Items.Add("Продукты питания");
                    CategorySelect.Items.Add("Транспорт");
                    CategorySelect.Items.Add("Мобильная связь");
                    CategorySelect.Items.Add("Интернет");
                    CategorySelect.Items.Add("Развлечения");
                    CategorySelect.Items.Add("Другое");
                    break;
            }
        }
    }
}
